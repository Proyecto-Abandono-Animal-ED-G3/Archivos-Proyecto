package Control;

import Grafica.Ventana_Proyecto;
import Logica.*;

//HOLA A TODOS, ESTE ES LA BASE DEL PROYECTO DEL CURSO DE ESTRUCTURA DE DATOS. 


public class Principal extends  Ventana_Proyecto{
    public static void main(String[] args) {
        
        Ventana_Proyecto ventana1 = new Ventana_Proyecto();
        ventana1.setVisible(true);

        
    }
    
}