package Logica;

public class MyLinkedList<T> {
    private Node<T> first, last;
    private Integer counter;

    public MyLinkedList() {
            clear();
    }

    public MyLinkedList(T[] array ) {
            clear();
            for(int x=0; x<array.length; x++) {
                    if(x == 0)
                            addFirst(array[0]);
                    else
                            addLast(array[x]);
            }	
    }

    public void clear() {
            this.first = null;
            this.last = null;
            this.counter = 0;
    }

    public boolean isEmpty() {
            if(counter == 0)
                    return true;
            return false;
    }

    public void addFirst(T data) {
            Node<T> newNode = new Node<>(data);
            if(this.first == null) {
                    this.first = newNode;
                    this.last = first;
            }else {
                    this.first.setPrevious(newNode);
                    newNode.setNext(this.first);
                    this.first = newNode;
            }
            this.counter++;
    }

    public void addLast(T data) {
            Node<T> newNode = new Node<>(data);
            if(this.last == null) {
                    this.last = newNode;
                    this.first = last;
            }else {
                    this.last.setNext(newNode);
                    newNode.setPrevious(this.last);
                    this.last = newNode;
            }
            this.counter++;
    }

    public void removeFirst() {
            if(this.first == null) {
                    System.err.println("Error, la lista esta vacia");
                    return;
            }
            this.first = this.first.getNext();
            this.first.setPrevious(null);
            this.counter--;
    }

    public void removeLast() {
            if(this.first == null) {
                    System.err.println("Error, la lista esta vacia");
                    return;
            }
            this.last = this.last.getPrevious();
            this.last.getNext().setPrevious(null);
            this.last.setNext(null);
            this.counter--;
    }

    public T getFirst() {
            return this.first.getData();
    }

    public T getLast() {
            return this.last.getData();
    }

    public MyLinkedList<Integer> find(T data){
            MyLinkedList<Integer> indices = new MyLinkedList<>();
            if(isEmpty()) {
                    System.err.println("Error, la lista esta vacia");
                    indices.addFirst(-1);;
                    return indices;
            }
            Node<T> aux = this.first;
            Integer cont = 0;
            while(aux != null) {
                    if(data.equals(aux.getData())) 
                            indices.addLast(cont);
                    cont++;
                    aux = aux.getNext();
            }
            if(indices.isEmpty()) {
                    System.out.println("Error, elemento no encontrado");
                    indices.addFirst(-1);
                    return indices;
            }
            return indices;

    }

    private Node<T> read(Integer k){
            if(isEmpty()) {
                    System.err.println("Error, la lista esta vacia");
                    return null;
            }
            if(k < 0 || k >= this.counter) {
                    System.out.println("Error, indice no valido");
                    return null;
            }
            Node<T> aux = this.first;
            for(int x=0; x<k; x++) {
                    aux = aux.getNext();
            }
            return aux;
    }

    public void add(T data, Integer k) {
            if(k < 0 || k > this.counter) {
                    System.err.println("Error, indice no valido");
                    return;
            }
            if(k == 0) {
                    addFirst(data);
                    return;
            }
            if(k == this.counter) {
                    addLast(data);
                    return;
            }
            Node<T> newNode = new Node<>(data), aux = this.read(k-1);
            newNode.setNext(aux.getNext());
            aux.getNext().setPrevious(newNode);
            aux.setNext(newNode);
            newNode.setPrevious(aux);
            this.counter++;
    }

    public void pop(Integer k) {
            if(k < 0 || k >= this.counter) {
                    System.err.println("Error, indice no valido");
                    return;
            }
            if(k == 0) {
                    removeFirst();
                    return;
            }
            if(k == this.counter-1) {
                    removeLast();
                    return;
            }
            Node<T> aux = this.read(k);
            aux.getPrevious().setNext(aux.getNext());
            aux.getNext().setPrevious(aux.getPrevious());
            aux.setNext(null);
            aux.setPrevious(null);
            this.counter--;

    }

    public T get(Integer k) {
            if(k < 0 || k >= this.counter) {
                    System.err.println("Error, indice no valido");
                    return null;
            }
            Node<T> aux = this.read(k);
            return aux.getData();
    }

    public Integer size() {
            return this.counter;
    }
	
@Override
public String toString(){
	if(isEmpty()) {
            return "[]";
	}
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Node<T> aux = this.first;
        while (aux != null){
            sb.append(aux.getData());
            sb.append(", ");
            aux = aux.getNext();
        }
        String toReturn = sb.toString();
        toReturn =  toReturn.substring(0, sb.length() - 2);
        return toReturn+"]";
    }	
}