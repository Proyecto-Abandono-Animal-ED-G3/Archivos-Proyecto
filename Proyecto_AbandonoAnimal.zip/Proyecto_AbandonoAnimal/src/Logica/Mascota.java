package Logica;

public class Mascota<T> {
    
}
