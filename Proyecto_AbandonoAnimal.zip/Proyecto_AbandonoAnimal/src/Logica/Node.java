package Logica;

class Node<T> {
    private Node<T> next, previous;
    private T data;
    
    public Node(T data){
        this.next = null;
        this.previous = null;
        this.data = data;
    }

    public Node<T> getNext() {
        return next;
    }

    public void setNext(Node<T> next) {
        this.next = next;
    }

    public Node<T> getPrevious() {
        return previous;
    }

    public void setPrevious(Node<T> previous) {
        this.previous = previous;
    }

    public T getData() {
        return data;
    }    
}